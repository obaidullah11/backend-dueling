import base64
import requests
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

# KPay Credentials and Test Environment
TRAN_PORTAL_ID = "540801"
TRAN_PORTAL_PASSWORD = "540801pg"
RESOURCE_KEY = "9D2JJ07HA1Y47RF3"
BASE_URL = "https://kpaytest.com.kw"  # Test environment URL


# Utility function for basic authentication
def get_auth_header():
    credentials = f"{TRAN_PORTAL_ID}:{TRAN_PORTAL_PASSWORD}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    return {"Authorization": f"Basic {encoded_credentials}"}


# 1. Initiate Payment API
@csrf_exempt
def initiate_payment(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            order_id = data.get("order_id")
            amount = data.get("amount")
            customer_name = data.get("customer_name", "Guest")
            customer_email = data.get("customer_email", "")
            customer_phone = data.get("customer_phone", "")
            redirect_url = data.get("redirect_url", "")

            payload = {
                "terminal_id": TRAN_PORTAL_ID,
                "order_id": order_id,
                "amount": amount,
                "currency": "KWD",
                "redirect_url": redirect_url,
                "resource_key": RESOURCE_KEY,
                "customer_name": customer_name,
                "customer_email": customer_email,
                "customer_phone": customer_phone,
            }

            headers = get_auth_header()
            headers.update({"Content-Type": "application/json"})

            # Sending request to KPay API
            response = requests.post(
                f"{BASE_URL}/api/payment/initiate", json=payload, headers=headers
            )

            # Return KPay response
            if response.status_code == 200:
                return JsonResponse(response.json(), status=200)
            else:
                return JsonResponse({"error": "Failed to initiate payment"}, status=400)

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

    return JsonResponse({"error": "Invalid request method"}, status=405)


# 2. Callback URL (Handle KPay redirect)
@csrf_exempt
def kpay_callback(request):
    if request.method == "POST" or request.method == "GET":
        try:
            # KPay will send the transaction status as query parameters or in body
            data = request.GET or request.POST
            order_id = data.get("order_id")
            status = data.get("transaction_status")
            transaction_id = data.get("transaction_id")

            return JsonResponse(
                {
                    "message": "Payment status received",
                    "order_id": order_id,
                    "transaction_status": status,
                    "transaction_id": transaction_id,
                },
                status=200,
            )

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

    return JsonResponse({"error": "Invalid request method"}, status=405)


# 3. Verify Payment Status API
@csrf_exempt
def verify_payment(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            order_id = data.get("order_id")

            payload = {
                "terminal_id": TRAN_PORTAL_ID,
                "order_id": order_id,
                "resource_key": RESOURCE_KEY,
            }

            headers = get_auth_header()
            headers.update({"Content-Type": "application/json"})

            # Sending request to KPay API for payment verification
            response = requests.post(
                f"{BASE_URL}/api/payment/status", json=payload, headers=headers
            )

            # Return KPay verification response
            if response.status_code == 200:
                return JsonResponse(response.json(), status=200)
            else:
                return JsonResponse({"error": "Failed to verify payment"}, status=400)

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

    return JsonResponse({"error": "Invalid request method"}, status=405)
