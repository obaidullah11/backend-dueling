from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import Notification
from users.models import User
from .serializers import NotificationSerializer

class UserNotificationsAPIView(APIView):
    def get(self, request, user_id):
        # Check if the user exists
        user = get_object_or_404(User, id=user_id)
        # Get all notifications for the user
        notifications = Notification.objects.filter(user=user)
        # Serialize the notifications
        serializer = NotificationSerializer(notifications, many=True)
        
        # Custom response structure
        return Response({
            "success": True,
            "message": "Notifications retrieved successfully",
            "data": serializer.data
        }, status=status.HTTP_200_OK)
class MarkNotificationsAsReadAPIView(APIView):
    def put(self, request, user_id):
        # Check if the user exists
        user = get_object_or_404(User, id=user_id)
        # Update all notifications for the user
        updated_count = Notification.objects.filter(user=user, is_read=False).update(is_read=True)
        
        # Custom response structure
        return Response({
            "success": True,
            "message": f"{updated_count} notifications marked as read",
            "data": None
        }, status=status.HTTP_200_OK)